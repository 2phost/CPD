Para correr com os tempos basta compilar com a flag -DVERBOSE=1.

O número de threads está a ser definido pela variável de ambiente OMP_NUM_THREADS, 
não sendo especificado em nenhuma parte do código o número de threads que estão a correr.
